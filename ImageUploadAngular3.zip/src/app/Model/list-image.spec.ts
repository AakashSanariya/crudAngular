import { ListImage } from './list-image';

describe('ListImage', () => {
  it('should create an instance', () => {
    expect(new ListImage()).toBeTruthy();
  });
});
