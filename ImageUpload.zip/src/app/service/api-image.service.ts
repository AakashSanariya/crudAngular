import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {Observable} from "rxjs/index";
import {ApiResponse} from "../Model/api-response";

@Injectable({
  providedIn: 'root'
})
export class ApiImageService {

  constructor(private http: HttpClient) { }
  httpOptions = {
  headers: new HttpHeaders({
    // 'Content-Type': 'application/json',
    // 'Accept': 'application/json',
    // 'Access-Control-Request-Methods': 'POST',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,OPTION',

  })
  };
  baseUrl: string = 'http://api.imageupload.com/api';
  login(loginPayLoad): Observable<ApiResponse[]>{
    console.log(loginPayLoad);
    let name = this.http.post<ApiResponse[]>(this.baseUrl + '/users/login', loginPayLoad, this.httpOptions);
    return name;
  }
}
