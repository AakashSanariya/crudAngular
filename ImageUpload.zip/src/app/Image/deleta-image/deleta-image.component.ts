import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deleta-image',
  templateUrl: './deleta-image.component.html',
  styleUrls: ['./deleta-image.component.css']
})
export class DeletaImageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
