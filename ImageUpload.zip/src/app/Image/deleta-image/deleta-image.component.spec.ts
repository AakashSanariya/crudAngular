import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeletaImageComponent } from './deleta-image.component';

describe('DeletaImageComponent', () => {
  let component: DeletaImageComponent;
  let fixture: ComponentFixture<DeletaImageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeletaImageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeletaImageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
