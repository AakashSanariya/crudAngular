import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-image',
  templateUrl: './list-image.component.html',
  styleUrls: ['./list-image.component.css']
})
export class ListImageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
