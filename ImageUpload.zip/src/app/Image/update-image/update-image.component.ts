import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-image',
  templateUrl: './update-image.component.html',
  styleUrls: ['./update-image.component.css']
})
export class UpdateImageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
