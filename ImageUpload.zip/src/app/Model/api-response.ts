export class ApiResponse {
    email: string;
    password: string;
}
