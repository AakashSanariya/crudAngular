import { ApiResponse } from './api-response';

describe('ApiResponse', () => {
  it('should create an instance', () => {
    expect(new ApiResponse()).toBeTruthy();
  });
});
