import { Component, OnInit } from '@angular/core';
import {FormGroup, FormBuilder, Validators} from "@angular/forms";
import {Router} from "@angular/router";
import {ApiImageService} from "../service/api-image.service";
import {async} from "@angular/core/testing";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private formBuilder: FormBuilder, private router: Router, private apiService: ApiImageService) { }

  loginForm: FormGroup;
  inValidLogin: boolean = false;

  onSubmit(){
    if(this.loginForm.invalid){
      return;
    }
    const loginPayLoad = {
      email: this.loginForm.controls.email.value,
      password: this.loginForm.controls.password.value
    };
  this.apiService.login(loginPayLoad).subscribe(data => {
      alert(data);
    });
  }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      email: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

}
