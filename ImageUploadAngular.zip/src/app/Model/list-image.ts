export class ListImage {
    data: string;
    meta: string;
    ImageData: string;
}
