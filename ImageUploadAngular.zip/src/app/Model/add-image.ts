export class AddImage {
    name: string;
    path: string;
    data: string;
    meta: string;
}
