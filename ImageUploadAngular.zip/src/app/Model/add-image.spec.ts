import { AddImage } from './add-image';

describe('AddImage', () => {
  it('should create an instance', () => {
    expect(new AddImage()).toBeTruthy();
  });
});
