export class ApiResponse {
    email: string;
    password: string;
    data: string;
    meta: string;
    status_code: string;
    token: string;
}
